# module which import C files as strings

import os

from PLCObject import PLCObject, PLCprint
import ServicePublisher
